import React from 'react'

const ShipmentDetail = () => {
  return (
    <div>ShipmentDetail</div>
  )
}

export default ShipmentDetail