import React from 'react'

const language = [
    {code:"en", lang:"English"}
    {code:"jp", lang:"Japnes"}
]


const Language = () => {


  return (
    <div>Language-selector</div>
  )
}

export default Language